import 'package:fair/fair.dart';
import 'package:flutter/material.dart';

abstract class FairState1<T extends StatefulWidget> extends State<T> {

}

# example

example 工程提供了 Fair API 使用的标准 demo
